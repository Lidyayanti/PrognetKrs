@extends('template.mahasiswa.dashboard')

@section('dashboard-active','active')
@section('title','Dashboard')
@section('content')
//DASHBOARD
@endsection