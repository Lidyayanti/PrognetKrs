

<?php $__env->startSection('krs-input-active','active'); ?>
<?php $__env->startSection('krs-active','active'); ?>
<?php $__env->startSection('title','KRS Input'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item">Input KRS</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="conteiner-fluid">
    <div class="row">
        <div class="col-12 card">
            <h5 class="bg-primary mx-n2 mt-n2 p-2">PILIHAN MATAKULIAH</h5>
            <table id="tablekrs" class="display m-3" style="width:100%">
                <thead>
                    <tr>
                        <th>Nama Matakuliah</th>
                        <th>Kode</th>
                        <th>Semester</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
        
        <div class="card col-12">
            <h5 class="bg-secondary mx-n2 mt-n2 p-2">PILIHAN ANDA</h5>
            <table id="tableselect" class="display" style="width:100%">
                <thead>
                    <tr>
                        <th>Nama Matakuliah</th>
                        <th>Kode</th>
                        <th>Semester</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>

        <div class="col-lg-6 col-12 p-1">
            <button class="btn-block btn-secondary">BACK</button>
        </div>

        <div class="col-lg-6 col-12 p-1">
            <button class="btn-block btn-primary">KIRIM</button>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    $(document).ready(function() {
        $('#tablekrs').DataTable( {

        } );

        $('#tableselect').DataTable( {

        } );
    } );
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('template.mahasiswa.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PrognetKrs\resources\views/mahasiswa/transaksi-krs.blade.php ENDPATH**/ ?>