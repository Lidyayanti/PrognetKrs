

<?php $__env->startSection('dashboard-active','active'); ?>
<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>
//DASHBOARD
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.mahasiswa.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PrognetKrs\resources\views/mahasiswa/dashboard.blade.php ENDPATH**/ ?>